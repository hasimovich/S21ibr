#include "list.h"
#include <time.h> 
#include <stdio.h>

int main() {
//#ifdef DOOR_ADD

struct door doors_[N];
    srand(time(0)); 
    
    int seed = rand() % 10000;
    for (int i = 0; i < N; i++)
    {
        doors_[i].id = (i + seed) % N;
        doors_[i].status = rand() % 2;
    }

struct node *test=init(doors_);



struct door test1 = {21, 11};
//struct door test2 = {22, 12};

struct node *test3 = add_door(test, &test1);

struct node *tmp= test3;

while ( tmp->next != NULL)
{
 printf("%d - %d\n", tmp->door->id , tmp->door->status);
 tmp=tmp->next;
}
printf("%d - %d\n", tmp->door->id, tmp->door->status);
printf("SUCCESS");

destroy(test);

return 0;
}