#include "list.h"
#include <time.h> 
#include <stdio.h> 


struct stack* init(struct door* door) {
 struct stack* root =(struct stack*)malloc(sizeof(struct node));
 root ->door = door;
 root ->next = NULL;

 for (int i=1; i<N; i++) {
door++;
struct stack *newnode = (struct stack*)malloc(sizeof(struct node));
newnode->door = door;
newnode->next = NULL;
root=newnode;

 }

 return(root);
}

struct stack* add_door(struct stack* elem, struct door* door) {
    struct node *temp=(struct stack*)malloc(sizeof(struct node));
    temp->door =door;
    temp->next=elem ->next;
    elem -> next = temp;
   // temp->next=elem ->next;
    return elem;

    //p= struct node -> elem;
    //struct node -> elem = temp;
    //temp->door =


}

struct stack* find_door(int door_id, struct stack* root){
struct stack* res =NULL;
while (root->next != NULL){
if(root->door->id ==door_id) {
    res=root;
    break;
}   
root=root->next;

    
}
if (root->door->id ==door_id) res=root;

return res;
}

struct stack* remove_door(struct stack* elem, struct stack* root){
struct node* head = root;
if (root->next==elem) {
    head = elem->next;
    free(elem);
}else {
while (root->next != NULL )
{
    if (root->next == elem){
   root->next =elem->next;
   free(elem);}
}
}
root=root->next;
return head;
}
void destroy(struct stack* root){
    while (root->next != NULL)
    {
        struct stack* tmp = root;
       
        
            root=root->next;
            free(tmp);
    }
free(root);

}