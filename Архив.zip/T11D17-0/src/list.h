#include "door_struct.h"
#include <stdlib.h>
#include <stddef.h>
#define N 5
#ifndef NODE_H
#define NODE_H

struct stack* init(struct door* door);
struct stack* add_door(struct node* elem, struct door* door);
struct stack* find_door(int door_id, struct node* root);
struct stack* remove_door(struct node* elem, struct node* root);
void destroy(struct node* root3);

struct stack{
    struct door *door;
    struct stack *next;
};



#endif