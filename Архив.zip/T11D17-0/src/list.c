#include "list.h"
#include <time.h> 
#include <stdio.h> 


struct node* init(struct door* door) {
 struct node* root =(struct node*)malloc(sizeof(struct node));
 struct node* tmp = root;
 root ->door = door;
 root ->next = NULL;

 for (int i=1; i<N; i++) {
door++;
struct node *newnode = (struct node*)malloc(sizeof(struct node));
newnode->door = door;
newnode->next = NULL;
tmp->next=newnode;
tmp=newnode;

 }

 return(root);
}

struct node* add_door(struct node* elem, struct door* door) {
    struct node *temp=(struct node*)malloc(sizeof(struct node));
    temp->door =door;
    temp->next=elem ->next;
    elem -> next = temp;
   // temp->next=elem ->next;
    return elem;

    //p= struct node -> elem;
    //struct node -> elem = temp;
    //temp->door =


}

struct node* find_door(int door_id, struct node* root){
struct node* res =NULL;
while (root->next != NULL){
if(root->door->id ==door_id) {
    res=root;
    break;
}   
root=root->next;

    
}
if (root->door->id ==door_id) res=root;

return res;
}

struct node* remove_door(struct node* elem, struct node* root){
struct node* head = root;
if (root->next==elem) {
    head = elem->next;
    free(elem);
}else {
while (root->next != NULL )
{
    if (root->next == elem){
   root->next =elem->next;
   free(elem);break;}
}
}
root=root->next;
return head;
}
void destroy(struct node* root){
    while (root->next != NULL)
    {
        struct node* tmp = root;
       
        
            root=root->next;
            free(tmp);
    }
free(root);

}