#include "../code-samples/binary_files_common_functions.h"

// void writete, int index);

int main() {
    int menu, size;

    char c;
    char way[4096];
    FILE *fp;

    struct my_struct one_some;
    struct my_struct two_some;

    if (scanf("%d%c", &menu, &c) != 2 || c != '\n')
        printf("n/a\n");
    else {
        switch (menu) {
            case 0:
                scanf("%s", way);
                fp = fopen(way, "rb");
                if (fp == NULL || fscanf(fp, "%c", &c) == EOF)
                    printf("n/a\n");
                else {
                    fseek(fp, 0, SEEK_END);
                    size = ftell(fp) / sizeof(struct my_struct);
                    fseek(fp, 0, SEEK_SET);
                    for (int i = 0; i <= size; i++) {
                        fread(&one_some, sizeof(struct my_struct), 1, fp);
                        printf("%d.%d.%d %d:%d:%d status-%d code-%d\n", one_some.year, one_some.month,
                               one_some.day, one_some.hour, one_some.minute, one_some.second, one_some.status,
                               one_some.code);
                    }
                }
                fclose(fp);
                break;

            case 1:

                scanf("%s", way);
                fp = fopen(way, "r+b");
                if (fp == NULL || fscanf(fp, "%c", &c) == EOF)
                    printf("n/a\n");
                else {
                    bubble(fp);
                    fseek(fp, 0, SEEK_END);
                    size = ftell(fp) / sizeof(struct my_struct);
                    fseek(fp, 0, SEEK_SET);
                    for (int i = 0; i <= size; i++) {
                        fread(&one_some, sizeof(struct my_struct), 1, fp);
                        printf("%d.%d.%d %d:%d:%d status-%d code-%d\n", one_some.year, one_some.month,
                               one_some.day, one_some.hour, one_some.minute, one_some.second, one_some.status,
                               one_some.code);
                    }
                }

                fclose(fp);
                break;
            case 2:;
                scanf("%s", way);
                fp = fopen(way, "a+b");
                if (fp == NULL || fscanf(fp, "%c", &c) == EOF)
                    printf("n/a\n");
                else {
                    struct my_struct add_to_file;

                    if (scanf("%d %d %d %d %d %d %d %d", add_to_file.year, add_to_file.month, add_to_file.day,
                              add_to_file.hour, add_to_file.minute, add_to_file.second, add_to_file.status,
                              add_to_file.code) != 8)
                        printf("nnnn/a");
                    else {
                        fwrite(&add_to_file, sizeof(struct my_struct), 1, fp);
                        bubble(fp);
                        fseek(fp, 0, SEEK_END);
                        size = ftell(fp) / sizeof(struct my_struct);
                        fseek(fp, 0, SEEK_SET);
                        for (int i = 0; i <= size; i++) {
                            fread(&one_some, sizeof(struct my_struct), 1, fp);
                            printf("%d.%d.%d %d:%d:%d status-%d code-%d\n", one_some.year, one_some.month,
                                   one_some.day, one_some.hour, one_some.minute, one_some.second,
                                   one_some.status, one_some.code);
                        }
                    }
                }

                fclose(fp);
                break;
            default:
                printf("n/a\n");
                break;
        }
    }
    fflush(stdin);

    return 0;
}
