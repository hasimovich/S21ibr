#include <stdio.h>
#include <stdlib.h>

/*
    1 6 7
    2 5 8
    3 4 9
*/
//void sort_vertical(int **matrix, int n, int m, int **result_matrix);

/*
    1 2 3
    6 5 4
    7 8 9
*/
//void sort_horizontal(int **matrix, int n, int m, int **result_matrix);

int inputxy(int *y, int *x);

int input(int **parray, int y, int x);
void output(int **matrix, int n, int m);


void main()
{
    int **matrix, **result;
    int y,x;
    int *m2;

    if (inputxy(&y,&x) ==0 ) //input(matrix, y, x)==0)
     printf("n/a"); 
        else { 

            matrix = (int **)malloc(y * x * sizeof(int) + y * sizeof(int *));
            if (matrix == NULL) 
                printf("n/a"); else {
                m2 = (int *)(matrix + y);
                for (int i = 0; i < y; i++) matrix[i] = m2 + x * i;}


                 if (input((int **)matrix, y, x) == 0) printf("m/a"); else { 



printf("WoW");



    
   // sort_vertical(matrix, y, x, result);
  //  output(result);
    
   // sort_horizontal(matrix, n, m, result);
   // output(result);
       }
}
}

int inputxy(int *y, int *x) {
    int res = 0;
    char c;

    if (((scanf("%d%d%c", y, x, &c) != 3 || *y <= 0) || *x <= 0) ||
        (c != '\n' )) {
       // printf("scan %d %d", *y, *x);
        res = 0;
    } else {
        res = 1;
    }
    return res;
}

int input(int **parray, int y, int x) {
    int res = 0;
    char c;
    for (int i = 0; i < y; i++) {
        for (int j = 0; j < x; j++) {
            //  printf("rweerw");
            if (scanf("%d%c", *(parray + i) + j, &c) != 2) {
                res = 0;
                break;
            } else res =1;
        }
        if (res == 0) break;
    }

    return res;



}