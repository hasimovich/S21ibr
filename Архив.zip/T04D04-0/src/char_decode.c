#include <stdio.h>
/*
int hex(int x);

int f2(int x);
*/
int main(void) {
    int x, k = 1, i = 2, j = 2;
    char c;
    /*if (scanf("%d%c", &x, &c) != 2 || c != '\n'||x<0||x>255) {
        printf("n/a\n");
    }*/
   // k = f1(x);
   scanf("%X", &x);
   //x=c;
    printf("%X\n", x);

    return 0;
}
/*
int hex(int x) {
    //char s1, =
            }

int f1(int x) {
    int tmp;
    for (int i = 2; i < x; i++) {
        for (int j = x; j >= 2; j--) {
            if (i * j == x) {
                tmp = f2(j);
                if (tmp == 0) return j;
            }
        }
    }
    return x;
}*/