#include <stdio.h>

int fib(int x);

//int f2(int x);

int main(void) {
    int x;
    char c;
   
   if(scanf("%d%c", &x, &c)!=2||c!='\n') {
    printf("n/a");
   } else {
   if(x==0) {printf("%d\n", x);}
   else {
    printf("%d\n", fib(x));
   }}
    return 0;
}

int fib(int x) {
    if(x==1||x==2) {
        return 1;
    }
    else {
        return(fib(x-1)+fib(x-2));
    }
      
    }

            
/*
int f1(int x) {
    int tmp;
    for (int i = 2; i < x; i++) {
        for (int j = x; j >= 2; j--) {
            if (i * j == x) {
                tmp = f2(j);
                if (tmp == 0) return j;
            }
        }
    }
    return x;
}*/