#include <stdio.h>

int f1(int x);

int f2(int x);

int main(void) {
    int x, k = 1, i = 2, j = 2;
    char c;
    if (scanf("%d%c", &x, &c) != 2 || c != '\n') {
        printf("n/a\n");
    }
    if (x < 0) x = x * -1;
    k = f1(x);
    printf("%d\n", k);

    return 0;
}

int f2(int x) {
    for (int i = 2; i < x; i++) {
        for (int j = x; j >= 2; j--) {
            if (i * j == x) {
                return 1;
            }
        }
    }
    return 0;
}
int f1(int x) {
    int tmp;
    for (int i = 2; i < x; i++) {
        for (int j = x; j >= 2; j--) {
            if (i * j == x) {
                tmp = f2(j);
                if (tmp == 0) return j;
            }
        }
    }
    return x;
}