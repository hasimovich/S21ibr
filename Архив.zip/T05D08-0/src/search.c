
#include <math.h>
#include <stdio.h>
#define NMAX 30

double mean(int *a, int n);
double variance(int *a, int n);
int input(int *a, int *n);
int output_result(int *a, int n);

int main() {
    int n, data[NMAX];

    if (input(data, &n) != 1) {
        printf("n/a");
        return 0;
    }
    if (output_result(data, n) == 0) printf("%d", 0);
    return 0;
}

int input(int *a, int *n) {
    char c;
    if (scanf("%d%c", n, &c) != 2 || (c != '\n') || *n > NMAX || *n <= 0) {
        return 0;
    } else {
        for (int *p = a; p - a < *n; p++) {
            scanf("%d", p);
        }
        scanf("%c", &c);
        if (c != '\n') {
            return 0;
        }
    }
    return 1;
}

double mean(int *a, int n) {
    double m = 0;

    for (int *p = a; p - a < n; p++) m += *p;

    return m / n;
}

double variance(int *a, int n) {
    double variance = 0;
    double meanv = 0;
    for (int *p = a; p - a < n; p++) meanv += *p;

    meanv = meanv / n;

    for (int *p = a; p - a < n; p++) variance += (meanv - *p) * (meanv - *p);

    return variance / n;
}

int output_result(int *a, int n) {
    for (int *p = a; p - a < n; p++)

        if ((*p % 2 == 0) && (*p >= mean(a, n)) && (*p != 0) &&
            (*p < (mean(a, n) + 3 * sqrt(variance(a, n))))) {
            printf("%d", *p);
            return *p;
        }
    return 0;
}