#include <math.h>
#include <stdio.h>
#define NMAX 30


int input(int *a, int *n);
void output_result(int *a, int n);

int main() {
    int n, data[NMAX];

    if (input(data, &n) != 1) {
        printf("n/a");
        return 0;
    }
 output_result(data, n);

    return 0;
}

int input(int *a, int *n) {
    char c;
    if (scanf("%d%c", n, &c) != 2 || (c != '\n') || *n > NMAX || *n <= 0) {
        return 0;
    } else {
        for (int *p = a; p - a < *n; p++) {
            scanf("%d", p);
            printf("%d ", *p);
        }
        scanf("%c", &c);
        if (c != '\n') {
            return 0;
        }
    }
    return 1;
}


void output_result(int *a, int n) {
    for (int *p = a; p - a < n; p++)

        
            printf("%d ", *p);
           
        }
   
