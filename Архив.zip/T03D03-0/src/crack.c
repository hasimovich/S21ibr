#include <stdio.h>
int main() {
    double x, y, n;
    printf("Введите два любых числа:\n");
    n = scanf("%lf %lf", &x, &y);
    if (n < 2) {
        printf("n/a\n");
    } else if ((x * x + y * y) < 25) {
        printf("GOTCHA\n");
    } else {
        printf("MISS\n");
    }

    return 0;
}