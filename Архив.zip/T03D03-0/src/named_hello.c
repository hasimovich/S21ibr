#include <stdio.h>
int main(void) {
    int a, b;
    printf("Введите целое число:\n");
    b = scanf("%d", &a);
    if (b == 0 || a < 0) {
        printf("Число не целое, сорян.\n");
    } else {
        printf("Hello, %d!\n", a);
    }
}