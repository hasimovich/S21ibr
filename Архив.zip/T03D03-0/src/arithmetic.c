#include <stdio.h>
int main() {
    int a, b, n, sum, raz, pz, ch;
    printf("Введите 2 целых числа через пробел:\n");
    n = scanf("%d %d", &a, &b);
    if (n < 2 || a < 0 || b < 0) {
        printf("Одно из чисел не целое!\n");
    } else if (b == 0) {
        sum = a + b;
        raz = a - b;
        pz = a * b;
        printf("%d %d %d n/a\n", sum, raz, pz);
    } else {
        sum = a + b;
        raz = a - b;
        pz = a * b;
        ch = a / b;
        printf("%d %d %d %d\n", sum, raz, pz, ch);
    }

    return 0;
}