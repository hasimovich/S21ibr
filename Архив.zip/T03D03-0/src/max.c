#include <stdio.h>
int main() {
    int a, b, n;
    printf("Введите два целых числа через пробел:\n");
    n = scanf("%d %d", &a, &b);
    if (n < 2 || a < 0 || b < 0) {
        printf("n/a\n");
    } else if (a >= b) {
        printf("%d\n", a);
    } else {
        printf("%d\n", b);
    }

    return 0;
}