#include <stdio.h>
#define NMAX 10

int input(int *a);
void output_result(int *a);
void bubble(int *a);

int main() {
  int data[NMAX];

  if (input(data) != 1)
    printf("n/a");
  else {

    output_result(data);
  }
  return 0;
}
int input(int *a) {
  char c;

  for (int *p = a; p - a < NMAX; p++) {
    scanf("%d", p);
  }
  scanf("%c", &c);
  if (c != '\n') {
    return 0;
  }
  return 1;
}

void bubble(int *a) {
  int c;
  for (int i = 0; i < NMAX - 1; i++) {
    for (int j = 0; j < NMAX - i - 1; j++) {

      if (a[j] > a[j + 1]) {

        c = a[j];
        a[j] = a[j + 1];
        a[j + 1] = c;
      }
    }
  }
}

void output_result(int *a) {
  bubble(a);

  for (int *p = a; p - a < NMAX; p++) {
    if (p - a == NMAX - 1)
      printf("%d\n", *p);
    else
      printf("%d ", *p);
  }
}
