/*------------------------------------
        Здравствуй, человек!
        Чтобы получить ключ
        поработай с комментариями.
-------------------------------------*/

#include <stdio.h>
#define NMAX 10

int input(int *buffer, int *length);
void output(int *buffer, int length);
int sum_numbers(int *buffer, int length);
// int find_numbers(int *buffer, int length, int number, int *numbers);
int numbergd(int *buffer, int length);
/*------------------------------------
        Функция получает массив данных
        через stdin.
        Выдает в stdout особую сумму
        и сформированный массив
        специальных элементов
        (выбранных с помощью найденной суммы):
        это и будет частью ключа
-------------------------------------*/
int main() {
  int data[NMAX], length;

  if (input(data, &length) != 1) {
    printf("n/a");
  } else {

    printf("%d\n", sum_numbers(data, length));
    output(data, length);
  }

  return 0;
}

int numbergd(int *buffer, int length) {
  int d = 0;

  for (int i = 0; i < length; i++) {
    if ((buffer[i] != 0) && sum_numbers(buffer, length) % buffer[i] == 0) {
      d++;
    }
  }
  // printf("%d",d);
  return d;
}
/*------------------------------------
        Функция должна находить
        сумму четных элементов
        с 0-й позиции.
-------------------------------------*/
int sum_numbers(int *bu, int length) {
  int sum = 0;

  for (int i = 0; i < length; i++) {
    if (*(bu + i) % 2 == 0) {
      sum = sum + *(bu + i);
    }
  }

  return sum;
}

/*------------------------------------
        Функция должна находить
        все элементы, на которые нацело
        делится переданное число и
        записывает их в выходной массив.
-------------------------------------*/
/*
int find_numbers(int *buffer, int length, int number, int *numbers) {
  int j = 0;
  int datanew[NMAX];
  for (int i = 0; i < length; i++)

    if ((buffer[i] != 0) && sum_numbers(buffer, length) % buffer[i] == 0) {
    }

  return 0;
}*/

int input(int *a, int *n) {

  char c;
  if (scanf("%d%c", n, &c) != 2 || (c != '\n') || *n > NMAX || *n <= 0) {
    return 0;
  } else {
    int ch = 0;
    for (int *p = a; p - a < *n; p++) {
      scanf("%d", p);
      if (*p % 2 == 0)
        ch++;
    }
    scanf("%c", &c);
    if (c != '\n' || ch == 0) {
      return 0;
    }
  }
  return 1;
}

void output(int *buffer, int length) {

  int datanew[NMAX];

  int d = 0;

  for (int i = 0; i < length; i++)

  {
    if (buffer[i] != 0 && sum_numbers(buffer, length) % buffer[i] == 0) {
      datanew[d] = buffer[i];
      d++;
    }
  }

  for (int i = 0; i < numbergd(buffer, length); i++) {
    numbergd(buffer, length) - i == 1 ? printf("%d", datanew[i])
                                      : printf("%d ", datanew[i]);
  }
}
