#include <stdio.h>
#define NMAX 10

int input(int *data, int *length, int *shift);
void output(int *buffer, int length);
void shiftl(int *data, int length);
void shiftr(int *data, int length);
void circle(int *buffer, int length, int shift);
int main() {
    int data[NMAX], length, shift;

    if (input(data, &length, &shift) != 1) {
        printf("n/a");
    } else {
        circle(data, length, shift);

        output(data, length);
    }

    return 0;
}

int input(int *a, int *n, int *shift) {
    char c;
    if (scanf("%d%c", n, &c) != 2 || (c != '\n') || *n > NMAX || *n <= 0) {
        return 0;
    } else {
        for (int *p = a; p - a < *n; p++) {
            scanf("%d", p);
        }
        scanf("%c", &c);
        if (c != '\n') {
            return 0;
        }
    }
    if (scanf("%d%c", shift, &c) != 2 || (c != '\n')) return 0;

    return 1;
}

void output(int *buffer, int length) {
    for (int i = 0; i < length; i++) {
        i == length - 1 ? printf("%d", buffer[i]) : printf("%d ", buffer[i]);
    }
}

void shiftl(int *data, int length) {
    int b = data[0];
    for (int i = 0; i < length - 1; i++) {
        data[i] = data[i + 1];
    }
    data[length - 1] = b;

    // for (int i=0; i<length;i++) printf("%d ", data[i]);
}
void shiftr(int *data, int length) {
    int b = data[length - 1];
    for (int i = length - 1; i > 0; i--) {
        data[i] = data[i - 1];
    }
    data[0] = b;

    // for (int i=0; i<length;i++) printf("%d ", data[i]);
}
void circle(int *buffer, int length, int shift) {
    int i = shift;

    if (i >= 0) {
        while (i != 0) {
            shiftl(buffer, length);
            i--;
        }
    } else {
        while (i != 0) {
            shiftr(buffer, length);
            i++;
        }
    }
}
/*
else {

for (int i=0; i<length ;i++)
{
i<length-shift?datash[i] = buffer[i+shift]:datash[i] = buffer[i+shift-length];
printf("%d ",datash[i]);
}
*/
