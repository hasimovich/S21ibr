#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "log_levels.h"
#include "logger.h"

int main() {
    char s[100];
    char ins[100];
    char *text = (char *)malloc(sizeof(char));
    char c;

    long size;
    FILE *fp;

#ifdef LOG
    FILE *log = log_init("log.txt");

#endif

    while (strcmp("-1", ins) != 0) {
        //   fflush(stdin);
        scanf("%100s", ins);
        //    fflush(stdin);
        if (strcmp("-1", ins) == 0) {
            break;
        } else if (strcmp("1", ins) == 0) {
            scanf("%100s", s);
            fp = fopen(s, "rt");
            if (fp == NULL || fscanf(fp, "%c", &c) == EOF) {
                printf("n/a\n");
#ifdef LOG
                logcat(log, "Wrong choice entered1", error);

#endif
                fclose(fp);
            } else {
                fseek(fp, 0, SEEK_END);
                size = ftell(fp);
                fseek(fp, 0, SEEK_SET);
                text = (char *)malloc(sizeof(char) * size);
                fread(text, sizeof(char), size, fp);
                printf("%s\n", text);
                fclose(fp);
                free(text);
#ifdef LOG
                logcat(log, "The file has been read", info);

#endif
            }

        } else if (strcmp("2", ins) == 0) {
            // printf("ecre");
            rewind(stdin);
            char input_str[1000];
            fgets(input_str, 1000, stdin);
            fp = fopen(s, "rt");
            if (fp == NULL) {
#ifdef LOG
                logcat(log, "Dont read file", error);

#endif
                printf("n/a\n");
                fclose(fp);
            } else {
                fclose(fp);
                fp = fopen(s, "a");

                //
                printf("%s\n", input_str);
                fprintf(fp, "%s\n", input_str);
                fclose(fp);
            }

        } else if (strcmp("3", ins) == 0) {
            int shift;

            // fflush(stdin);
            if (scanf("%d", &shift) != 1) {
                printf("n/a\n");
#ifdef LOG
                logcat(log, "Wrong choice entered2", error);

#endif
            } else {
                //     if(dr=opendir(88)==NULL) printf("n/a\n");
            }

        }

        else {
#ifdef LOG
            logcat(log, "Wrong choice entered3", error);

#endif
            printf("n/a\n");
        }
    }
    //  free(text);
#ifdef LOG
    lod_close(log);

#endif
    return 0;
}
