#ifndef LOGGER
#define LOGGER

#include <stdio.h>
#include <time.h>
#include <string.h>
#include "log_levels.h"

int logcat (FILE* log_file, char* massege, enum log_level level);
int lod_close(FILE* log_file);
FILE* log_init(char* fn);

#endif