
#include "logger.h"


FILE* log_init(char* fn) {return fopen(fn, "w");}

int lod_close(FILE* log_file) {return fclose(log_file);}

int logcat (FILE* log_file, char* massege, enum log_level level) {
char mess[1000];
time_t tmm = time(NULL);
char date[10];
strftime(date, 10,"%T ", localtime(&tmm));
sprintf(mess, "[%i] ", level);
strcat(mess, date);
strcat(mess, massege);
strcat(mess, "\n");
fwrite(mess, strlen(mess),1, log_file);
return 0;
}
