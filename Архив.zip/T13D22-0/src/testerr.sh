echo "clang-format"
clang-format -n $1
clang-format -i $1
echo "-Wall -Werror -Wextra"
gcc -Wall -Werror -Wextra $1
#echo "cppcheck"
#cppcheck --enable=all --suppress=missingIncludeSystem $1
