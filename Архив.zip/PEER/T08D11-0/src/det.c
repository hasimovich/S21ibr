#include <math.h>
#include <stdio.h>
#include <stdlib.h>

double det(double **matrix, int dim_c, int dim_l);
int input(double ***mtx, int *dim_c, int *dim_l);
void output(double det);

int main(void) {
    double ***matrix = malloc(sizeof(double **));
    int dim_c, dim_l;
    if (input(matrix, &dim_c, &dim_l)) {
        output(det(*matrix, dim_c, dim_l));
    } else {
        printf("n/a");
    }
    free(*matrix);
    free(matrix);
    return 0;
}

int input(double ***mtx, int *dim_c, int *dim_l) {
    double *ptr;
    int status = 1;
    char check, check_1, check_2;
    if (scanf("%d%c%d%c", dim_c, &check_1, dim_l, &check_2) == 4 && *dim_c == *dim_l && *dim_c > 0) {
        *mtx = malloc(*dim_c * (*dim_l) * sizeof(double) + *dim_c * sizeof(double *));
        ptr = (double *)(*mtx + *dim_c);
        for (int i = 0; i < *dim_c; i++) {
            (*mtx)[i] = ptr + *dim_c * i;
            for (int j = 0; j < *dim_l; j++) {
                if (j == *dim_l - 1) {
                    if (scanf("%lf%c", &(*mtx)[i][j], &check) != 2 || check != 10) {
                        status = 0;
                    }
                } else {
                    if (scanf("%lf%c", &(*mtx)[i][j], &check) != 2 || check != 32) {
                        status = 0;
                    }
                }
            }
        }
    } else {
        status = 0;
    }
    return status;
}

double det(double **matrix, int dim_c, int dim_l) {
    double result = 0;
    if (dim_l == 2) {
        result = (matrix[0][0] * matrix[1][1]) - (matrix[0][1] * matrix[1][0]);
    } else {
        for (int i = 0; i < dim_c; i++) {
            double **buffer = malloc((dim_c - 1) * sizeof(double *));
            for (int i = 0; i < (dim_c - 1); i++) {
                buffer[i] = malloc((dim_c - 1) * sizeof(double));
            }
            int del_i = 0;
            for (int i_b = 0; i_b < dim_c - 1; i_b++) {
                if (i_b == 0) {
                    del_i = 1;
                }
                int del_j = 0;
                for (int j_b = 0; j_b < dim_c - 1; j_b++) {
                    if (j_b == i) {
                        del_j = 1;
                    }
                    buffer[i_b][j_b] = matrix[i_b + del_i][j_b + del_j];
                }
            }
            result += (pow(-1, i) * (matrix[0][i]) * (det(buffer, dim_l - 1, dim_l - 1)));
            for (int i = 0; i < dim_c - 1; i++) {
                free(buffer[i]);
            }
            free(buffer);
        }
    }
    return result;
}

void output(double det) { printf("%.6f", det); }
