#include <stdio.h>
#include <stdlib.h>

/*
    1 6 7
    2 5 8
    3 4 9
*/
void sort_vertical(int **matrix, int dim_c, int dim_l, int ***result_matrix);

/*
    1 2 3
    6 5 4
    7 8 9
*/
void sort_horizontal(int **matrix, int n, int m, int ***result_matrix);

int input(int ***mtx, int *dim_c, int *dim_l);
void output(int **mtx, int dim_c, int dim_l);
int *sort(int *mass, int first, int last);
void swap(int *left, int *right);

int main(void) {
    int ***matrix = malloc(sizeof(int **));
    int dim_c, dim_l;
    if (input(matrix, &dim_c, &dim_l)) {
        int **result_matrix = malloc(dim_c * sizeof(int *));
        for (int i = 0; i < dim_c; i++) {
            result_matrix[i] = malloc(dim_l * sizeof(int));
        }
        sort_vertical(*matrix, dim_c, dim_l, &result_matrix);
        output(result_matrix, dim_c, dim_l);
        printf("\n");
        printf("\n");
        sort_horizontal(*matrix, dim_c, dim_l, &result_matrix);
        output(result_matrix, dim_c, dim_l);
        free(*matrix);
        free(matrix);
        for (int i = 0; i < dim_c; i++) {
            free(result_matrix[i]);
        }
        free(result_matrix);
    } else {
        printf("n/a");
    }
    return 0;
}

int input(int ***mtx, int *dim_c, int *dim_l) {
    int *ptr;
    int status = 1;
    if (scanf("%d %d", dim_c, dim_l) == 2 && *dim_c > 0 && *dim_l > 0) {
        *mtx = malloc(*dim_c * (*dim_l) * sizeof(int) + *dim_c * sizeof(int *));
        ptr = (int *)(*mtx + *dim_c);
        for (int i = 0; i < *dim_c; i++) {
            (*mtx)[i] = ptr + *dim_c * i;
            for (int j = 0; j < *dim_l; j++) {
                if (scanf("%d", &(*mtx)[i][j]) != 1) {
                    status = 0;
                }
            }
        }
    } else {
        status = 0;
    }
    return status;
}

void output(int **mtx, int dim_c, int dim_l) {
    for (int i = 0; i < dim_c; i++) {
        for (int j = 0; j < dim_l; j++) {
            if (j == dim_l - 1) {
                printf("%d", mtx[i][j]);
            } else {
                printf("%d ", mtx[i][j]);
            }
        }
        if (i != dim_c - 1) {
            printf("\n");
        }
    }
}

void sort_horizontal(int **matrix, int dim_c, int dim_l, int ***result_matrix) {
    int *buffer = malloc(dim_c * dim_l * sizeof(int));
    int count = 0;
    for (int i = 0; i < dim_c; i++) {
        for (int j = 0; j < dim_l; j++) {
            buffer[count] = matrix[i][j];
            count++;
        }
    }
    buffer = sort(buffer, 0, dim_c * dim_l - 1);
    count = 0;
    for (int i = 0; i < dim_c; i++) {
        if (i % 2 == 0) {
            for (int j = 0; j < dim_l; j++) {
                (*result_matrix)[i][j] = buffer[count];
                count++;
            }
        } else {
            for (int j = dim_l - 1; j >= 0; j--) {
                (*result_matrix)[i][j] = buffer[count];
                count++;
            }
        }
    }
    free(buffer);
}

void sort_vertical(int **matrix, int dim_c, int dim_l, int ***result_matrix) {
    int *buffer = malloc(dim_c * dim_l * sizeof(int));
    int count = 0;
    for (int i = 0; i < dim_c; i++) {
        for (int j = 0; j < dim_l; j++) {
            buffer[count] = matrix[i][j];
            count++;
        }
    }
    buffer = sort(buffer, 0, dim_c * dim_l - 1);
    count = 0;
    for (int i = 0; i < dim_l; i++) {
        if (i % 2 == 0) {
            for (int j = 0; j < dim_c; j++) {
                (*result_matrix)[j][i] = buffer[count];
                count++;
            }
        } else {
            for (int j = dim_c - 1; j >= 0; j--) {
                (*result_matrix)[j][i] = buffer[count];
                count++;
            }
        }
    }
    free(buffer);
}

int *sort(int *mass, int first, int last) {
    if (first < last) {
        int left = first, right = last, middle = mass[(left + right) / 2];
        do {
            while (mass[left] < middle) {
                left++;
            }
            while (mass[right] > middle) {
                right--;
            }
            if (left <= right) {
                swap(mass + left, mass + right);
                left++;
                right--;
            }
        } while (left <= right);
        sort(mass, first, right);
        sort(mass, left, last);
    }
    return mass;
}

void swap(int *left, int *right) {
    int buffer = *right;
    *right = *left;
    *left = buffer;
}