#include "print_module.h"

#include <stdio.h>

char print_char(char ch) { return putchar(ch); }

void print_log(char (*print)(char), char* message) {
    for (; *message; message++) {
        print(*message);
    }
}