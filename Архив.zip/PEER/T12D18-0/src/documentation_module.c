#include "documentation_module.h"

#include <stdarg.h>
int validate(char* data) {
    int validation_result = !strcmp(data, Available_document);
    printf("%d \t", validation_result);
    return validation_result;
}

int* check_available_documentation_module(int (*validate)(char*), int document_count, ...) {
    static int res[16] = {[0 ... 15] - 1};

    va_list valist;
    va_start(valist, document_count);

    for (int i = 0; i < document_count; i++) res[i] = validate(va_arg(valist, char*));

    va_end(valist);

    return res;
}
