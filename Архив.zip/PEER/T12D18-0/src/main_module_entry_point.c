#include <stdio.h>
#include <string.h>
#include <time.h>
//#include "print_module.c"
#include "documentation_module.h"
#include "print_module.h"

int main()

{
#ifdef PRINT_MODULE
    char a[] = Log_prefix;
    char b[] = Module_load_success_message;
    char c[] = " HH:MM:SS ";
    char d[strlen(a) + strlen(b) + strlen(c) + 20];
    strcpy(d, a);

    struct tm* timeinfo;
    time_t rawtime;
    time(&rawtime);
    timeinfo = localtime(&rawtime);

    char tmp[6];
    sprintf(tmp, " %d:", timeinfo->tm_hour);
    strcpy(c, tmp);
    sprintf(tmp, "%d:", timeinfo->tm_min);
    strcat(c, tmp);
    sprintf(tmp, "%d ", timeinfo->tm_sec);
    strcat(c, tmp);
    strcat(d, c);
    strcat(d, b);

    print_log(print_char, d);
#endif
#ifdef DOC_MOD
    // availability_mask = check_available_documentation_module(validate, Documents_count, Documents);

    char* docs[] = {Documents};
    // char avail_docs[] = Available_document;
    // int doc_i[ Documents_count] ={-1};
    int i = 0;
    for (; i < 15; i++) {
        if (!docs[i][0]) {
            break;
        }
    }
    int* check_int;
    check_int = check_available_documentation_module(validate, i, docs[0], docs[1], docs[2], docs[3]);
    printf("%d ", check_int[3]);
    // char * ptr;
    // char un[3] = "un";
    char zero[2] = "";
    for (int j = 0; j < 15; j++) {
        // if (check_int[j]>0) {ptr = zero;}
        // else {ptr = un;}
        printf("document: %savailable\n", zero);
    }

    // Output availability for each document....
#endif
    return 0;
}
