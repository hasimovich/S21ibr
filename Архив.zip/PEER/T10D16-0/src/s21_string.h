#ifndef S21_STRING_H
#define S21_STRING_H

unsigned long long s21_strlen(const char *s);
int s21_strcmp(const char *s1, const char *s2);
char *s21_strcpy(char *s1, const char *s2);
char *s21_strcat(char *s1, const char *s2);
char *s21_strchr(const char *s, int c);
char *s21_strstr(const char *s1, const char *s2);
char *s21_strtok(char *s, const char *ct);

#endif