#include "s21_string.h"

#include <stdio.h>

unsigned long long s21_strlen(const char *s) {
    unsigned long long len = 0;
    while (*s++) {
        len++;
    }
    return len;
}

int s21_strcmp(const char *s1, const char *s2) {
    unsigned char c1, c2;
    int res = 0;
    int ret = 1;
    while (ret) {
        c1 = *s1++;
        c2 = *s2++;
        if (c1 != c2) {
            ret = 0;
            res = c1 < c2 ? -1 : 1;
        }
        if (!c1) break;
    }
    return res;
}

char *s21_strcpy(char *s1, const char *s2) {
    char *tmp = s1;

    while ((*s1++ = *s2++) != '\0') continue;
    return tmp;
}

char *s21_strcat(char *s1, const char *s2) {
    char *tmp = s1;

    while (*s1) s1++;
    while ((*s1++ = *s2++) != '\0') continue;
    return tmp;
}

char *s21_strchr(const char *s, int c) {
    char *res = NULL;
    int flag = 1;
    while (*s != (char)c && flag) {
        if (*s == '\0') {
            flag = 0;
        }
        s++;
    }
    if (flag) res = (char *)s;
    return res;
}

char *s21_strstr(const char *s1, const char *s2) {
    char *res = NULL;
    int ret = 1;
    unsigned long long l1, l2;
    l1 = 0;
    l2 = 0;

    l2 = s21_strlen(s2);
    if (!l2) {
        res = (char *)s1;
        ret = 0;
    }
    l1 = s21_strlen(s1);
    while (l1 >= l2 && ret) {
        l1--;
        if (!s21_strcmp(s1, s2)) {
            res = (char *)s1;
            ret = 0;
            continue;
        }

        s1++;
    }
    return res;
}

char *s21_strpbrk(const char *cs, const char *ct) {
    const char *sc1, *sc2;
    int flag = 1;
    char *res = NULL;
    for (sc1 = cs; *sc1 != '\0'; ++sc1) {
        for (sc2 = ct; *sc2 != '\0'; ++sc2) {
            if (flag)
                if (*sc1 == *sc2) {
                    res = (char *)sc1;
                    flag = 0;
                }
        }
    }
    if (flag) res = (char *)sc1;
    return res;
}

char *s21_strtok(char *s, const char *ct) {
    char *sbegin = NULL;
    char *end;
    int flag = 1;
    if (s == NULL) flag = 0;
    if (flag) {
        sbegin = s;
        end = s21_strpbrk(sbegin, ct);
        if (end && flag) *end++ = '\0';
        s = end;
    }
    return sbegin;
}
