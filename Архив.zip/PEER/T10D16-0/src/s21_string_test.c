#include "s21_string.h"

#include <stdio.h>

#ifdef strlen_tests
#define choice s21_strlen_test()
#endif

#ifdef strcmp_tests
#define choice s21_strcmp_test()
#endif

#ifdef strcpy_tests
#define choice s21_strcpy_test()
#endif

#ifdef strcat_tests
#define choice s21_strcat_test()
#endif

#ifdef strchr_tests
#define choice s21_strchr_test()
#endif

#ifdef strstr_tests
#define choice s21_strstr_test()
#endif

#ifdef strtok_tests
#define choice s21_strtok_test()
#endif

void s21_strlen_test();
void s21_strcmp_test();
void s21_strcpy_test();
void s21_strcat_test();
void s21_strchr_test();
void s21_strstr_test();
void s21_strtok_test();

int main() {
    choice;
    return 0;
}

void s21_strlen_test() {
    printf("strlen_test\n");
    printf("School_21\n");
    unsigned long long test_val = s21_strlen("School_21");
    printf("%lld\n", test_val);
    if (test_val == 9) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
    printf("\n");
    test_val = s21_strlen("");
    printf("%lld\n", test_val);
    if (test_val == 0) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
    printf("123 456 789 0\n");
    test_val = s21_strlen("123 456 789 0");
    printf("%lld\n", test_val);
    if (test_val == 13) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
}

void s21_strcmp_test() {
    printf("strcmp_test\n");
    printf("School_21 : School_21\n");
    int test_val = s21_strcmp("School_21", "School_21");
    printf("%d\n", test_val);
    if (test_val == 0) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
    printf("School_21 : School\n");
    test_val = s21_strcmp("School_21", "School");
    printf("%d\n", test_val);
    if (test_val == 1) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
    printf("School : School_21\n");
    test_val = s21_strcmp("School", "School_21");
    printf("%d\n", test_val);
    if (test_val == -1) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
}

void s21_strcpy_test() {
    printf("strcpy_test\n");
    printf("School_21\n");
    char *val = "School_21";
    char test1[11] = "";
    s21_strcpy(test1, val);
    printf("%s\n", test1);
    if (s21_strcmp("School_21", test1) == 0) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
    printf("\n");
    char test2[11] = "";
    val = "";
    s21_strcpy(test2, val);
    printf("%s\n", test2);
    if (s21_strcmp("", test2) == 0) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
    printf("123 123 123\n");
    char test3[11] = "";
    val = "123 123 123";
    s21_strcpy(test3, val);
    printf("%s\n", test3);
    if (s21_strcmp("123 123 123", test3) == 0) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
}

void s21_strcat_test() {
    printf("strcat_test\n");
    printf("School : _21\n");
    char *val = "_21";
    char test1[100] = "School";
    s21_strcat(test1, val);
    printf("%s\n", test1);
    if (s21_strcmp("School_21", test1) == 0) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
    printf(" : void\n");
    char test2[100] = "";
    val = "void";
    s21_strcat(test2, val);
    printf("%s\n", test2);
    if (s21_strcmp("void", test2) == 0) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
    printf("123 : 321\n");
    char test3[100] = "123";
    val = "321";
    s21_strcat(test3, val);
    printf("%s\n", test3);
    if (s21_strcmp("123321", test3) == 0) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
}

void s21_strchr_test() {
    printf("strchr_test\n");
    printf("School : l\n");
    char val[100] = "School";
    char *test = s21_strchr(val, (int)('l'));
    if (test != NULL) {
        printf("%ld\n", test - val);
        if (test - val == 5) {
            printf("SUCCESS\n");
        } else {
            printf("FAIL\n");
        }
    } else {
        printf("NULL\n");
        printf("FAIL\n");
    }
    printf("School : a\n");
    test = s21_strchr(val, (int)('a'));
    if (test != NULL) {
        printf("%s\n", test);
        printf("FAIL\n");
    } else {
        printf("NULL\n");
        printf("SUCCESS\n");
    }
    printf("School : o\n");
    test = s21_strchr(val, (int)('o'));
    if (test != NULL) {
        printf("%ld\n", test - val);
        if (test - val == 3) {
            printf("SUCCESS\n");
        } else {
            printf("FAIL\n");
        }
    } else {
        printf("NULL\n");
        printf("FAIL\n");
    }
}

void s21_strstr_test() {
    printf("strstr_test\n");
    printf("School_21 : 21\n");
    char val[100] = "School_21";
    char *search = "21";
    char *test = s21_strstr(val, search);
    if (test != NULL) {
        printf("%ld\n", test - val);
        if (test - val == 7) {
            printf("SUCCESS\n");
        } else {
            printf("FAIL\n");
        }
    } else {
        printf("NULL\n");
        printf("FAIL\n");
    }
    printf("School_21 : apple\n");
    search = "apple";
    test = s21_strstr(val, search);
    if (test != NULL) {
        printf("%s\n", test);
        printf("FAIL\n");
    } else {
        printf("NULL\n");
        printf("SUCCESS\n");
    }
    printf(": 42\n");
    char val1[100] = "";
    search = "42";
    test = s21_strstr(val1, search);
    if (test != NULL) {
        printf("%s\n", test);
        printf("FAIL\n");
    } else {
        printf("NULL\n");
        printf("SUCCESS\n");
    }
}

void s21_strtok_test() {
    printf("strstr_test\n");
    printf("School_21 : _\n");
    char val[100] = "School_21";
    char *search = "_";
    char *test = s21_strtok(val, search);
    if (test != NULL) {
        printf("%s\n", test);
        if (s21_strcmp("School", test) == 0) {
            printf("SUCCESS\n");
        } else {
            printf("FAIL\n");
        }
    } else {
        printf("NULL\n");
        printf("FAIL\n");
    }
    printf("School/21 : /\n");
    search = "/";
    test = s21_strtok(val, search);
    if (test != NULL) {
        printf("%s\n", test);
        if (s21_strcmp("School", test) == 0) {
            printf("SUCCESS\n");
        } else {
            printf("FAIL\n");
        }
    } else {
        printf("NULL\n");
        printf("FAIL\n");
    }
    printf("***$***: $\n");
    char val1[100] = "***$***";
    search = "$";
    test = s21_strtok(val1, search);
    if (test != NULL) {
        printf("%s\n", test);
        if (s21_strcmp("***", test) == 0) {
            printf("SUCCESS\n");
        } else {
            printf("FAIL\n");
        }
    } else {
        printf("NULL\n");
        printf("FAIL\n");
    }
}