#ifndef S21_STRLEN
#define S21_STRLEN

int s21_strlen(char *str);
int s21_strcmp(char *str1, char *str2);
// char *s21_strcpy(char *str1,char *str2);
// char* s21_strcat(char* dest, const char* str);
// char *s21_strchr(char *str, int ch);
// char *s21_strstr(char *str1,char *str2);
// char *s21_strtok(char *str1,char *str2);

#endif  // S21_STRLEN