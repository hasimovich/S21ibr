#ifndef S21_STRLEN
#define S21_STRLEN


void s21_strlen_test(char *str1, int res);
void s21_strcmp_test(char *str1, char *str2);
//void s21_strcpy_test(char *str1, char *str2);
//void s21_strcat_test(char *str1, char *str2);
//void s21_strchr_test(char *str1, int ch);
//void s21_strstr_test(char *str1, char *str2);
//void s21_strtok_test(char *str1, char *str2);

#endif //S21_STRLEN