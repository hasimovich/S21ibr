#include "s21_string.h"

#include <stdlib.h>

int s21_strlen(char *str) {
    int length = 0;

    for (; *(str + length); length++)
        ;

    return length;
}

int s21_strcmp(char *str1, char *str2) {
    for (; *str1 && *str1 == *str2; str1++, str2++)
        ;

    return *str1 - *str2;
}
/*
char *s21_strcpy(char *str1,char *str2) {
while (*str2 != '\0')
{
    *str1 = *str2;
    str1++;
    str2++;
}
 *str1 = '\0';

return str1;
}

char* s21_strcat(char* dest, const char* str) {

    char* ptr = dest + s21_strlen(dest);  // делаем так, чтобы `ptr` указывал на конец строки назначения

    while (*str != '\0') {  // добавляет символы источника к строке назначения

        *ptr++ = *str++;
    }
    *ptr = '\0';  // нулевая завершающая строка назначения
    return dest;
}



  //   if((str1==NULL)||(str2==NULL)) throw "Invalide arguments!";
    char *pt = str1;
    while(*pt!='\0') pt++;
    while(*str2!='\0') *pt++ = *str2++;
    *pt = '\0';
    return str1;









        char *str;
//        if((*str1=='\0')||(*str2=='\0')) {*str = str1;} else {

    int len1=s21_strlen(str1),len2=s21_strlen(str2);
    for (int i = 0; i < len1; i++) {*(str+i) = *(str1+i);}

    for(int i=len1;i<len1+len2;i++){
        str[i]=str2[i-len1];
    }
    str [len1+len2]= '\0';
//        }
    return str;*/

/*
char *s21_strchr(char *str, int ch){

char s;
for (int i = 0; *(str+i)!='\0'; i++)
{
   if(*(str+i) == ch) s=*(str+i);
}
return &s;

}

char *s21_strstr(char *str1,char *str2) {
char s;

for (int i=0; *(str1+i)!='\0'; i++) {

if(*(str1+i) == *str(str2)) {s=*(str+i);
for(j=0;*(str2+j)!='\0';j++) {
    if (*(str1+i+j)!=(str2+j)) break;
}
}
}
return s;

}

char *s21_strtok(char *str1,char *str2) {


    for (int i = 0; *(str1 +i) != '\0'; i++)
    {
     for (int j = 0; *(str2 +j) != '\0'; j++)
     {
       //if (str)
     }

    }


}

*/