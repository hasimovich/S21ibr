#include "s21_string.h"

#include <stdio.h>
#include <stdlib.h>

#include "s21_string_test.h"

void s21_strlen_test(char *str1, int res);
void s21_strcmp_test(char *str1, char *str2);
// void s21_strcpy_test(char *str1, char *str2);
// void s21_strcat_test(char *str1, char *str2);
// void s21_strchr_test(char *str1, int ch);
// void s21_strstr_test(char *str1, char *str2);
// void s21_strtok_test(char *str1, char *str2);

int main() {
#ifdef STRLEN

    char *test1 = "Hello 21_School!";
    char *test2 = "Hello 21_School\0";
    char *test3 = "Hello 21_School\n";

    int res1 = 16;
    int res2 = 15;
    int res3 = 16;

    s21_strlen_test(test1, res1);
    s21_strlen_test(test2, res2);
    s21_strlen_test(test3, res3);
    s21_strlen_test(test2, res3);

#endif  // STRLEN

#ifdef STRCMP

    char *test1 = "Hello 21_School!";
    char *test2 = "Hello 21_School!";
    char *test3 = "Hello 21_School?";

    s21_strcmp_test(test1, test2);
    s21_strcmp_test(test2, test3);
    s21_strcmp_test(test1, test3);

#endif  // STRCMP
        /*
        #ifdef STRCPY
    
    
        char *test1 = "21_School!";
        char *test2 = "Hello 21_School!";
        char *test3 = "The best of 21_School?";
    
    
        s21_strcpy_test(test2,test1);
        s21_strcpy_test(test3,test2);
        s21_strcpy_test(test1,test3);
    
    
        #endif //STRCPY
    
        #ifdef STRCAT
    
    
        char *test1 = "21_School!";
        char *test2 = "befgh";
        char *test3 = "The best of 21_School?";
    
    
        s21_strcat_test(test1,test2);
        s21_strcat_test(test2,test3);
        s21_strcat_test(test1,test3);
    
    
        #endif //STRCAT
    
        #ifdef STRCHR
    
    
        char *test1 = "21_School!";
        char *test2 = "Hello 21_School!";
        char *test3 = "The best of 21_School?";
    
        int ch1 = h;
        int ch2 = 2;
        int ch3 = S;
    
        s21_strchr_test(test1,ch1);
        s21_strchr_test(test2,ch2);
        s21_strchr_test(test1,ch3);
    
    
        #endif //STRCHR
    
        #ifdef STRSTR
    
    
        char *test1 = "21_School!";
        char *test2 = "Hello 21_School!";
        char *test3 = "The best of 21_School?";
    
    
        s21_strstr_test(test2,test1);
        s21_strstr_test(test3,test1);
        s21_strstr_test(test1,test1);
    
    
        #endif //STRSTR
    
        #ifdef STRTOK
    
    
        char *test1 = "21_School!";
        char *test2 = "Hello 21_School!";
        char *test3 = "The best of 21_School?";
        char *cut1 = "_";
        char *cut2 = " ";
        char *cut3 = " ";
    
        s21_strstr_test(test1,cut1);
        s21_strstr_test(test2,cut1);
        s21_strstr_test(test3,cut1);
    
    
        #endif //STRTOK
    
        return 0;
        }
    
    
    
        void s21_strlen_test(char *str1, int res) {
    
        if (s21_strlen(str1)==res) {
    
            printf("%s - %d - SUCCESS\n", str1, res );
        } else {
            printf("%s - %d - FAIL\n", str1, res);
        }
    
        }
    
        void s21_strcmp_test(char *str1, char *str2) {
    
        //printf("-%d-\n",s21_strcmp(str1, str2));
    
        if (s21_strcmp(str1,str2)==0) {
    
            printf("%s - %s - SUCCESS\n", str1, str2 );
        } else {
            printf("%s - %s - FAIL\n", str1, str2);
        }
    
        }
    
        void s21_strcpy_test(char *str1, char *str2){
    
        //printf("-%d-\n",s21_strcmp(str1, str2));
    
        if (s21_strlen(str1) >= s21_strlen(str2)) {
    
            printf("%s / %s - SUCCESS\n", str1, str2);
            printf("%s",s21_strcpy(str1,str2));
        } else {
            printf("%s / %s - FAIL\n", str1, str2);
    
        }
        }
    
        void s21_strcat_test(char *str1, char *str2){
    
        if (*str1!='\0'&&*str2!='\0') {
            printf("%s / %s - \n", str1, str2);
            s21_strcat(str1,str2);
         //   printf("%s - SUCCESS", str1);
        } else {
            printf("%s / %s - \n", str1, str2);
        //    printf("%s - FAIL", s21_strcat(str1, str2));
        }
        }
        /*
        void s21_strchr_test(char *str1, int ch) {
    
            printf("%s / %d - %s - SUCCESS\n", str1, ch, s21_strchr(str1, ch));
        //} else {
            printf("%s / %s - %s- FAIL\n", str1, str2, s21_strchr(str1, ch));
    
    
    
        }
    
        void s21_strstr_test(char *str1, char *str2) {
    
            printf("%s / %s - %d - SUCCESS\n", str1, str2, s21_strstr(str1, str2));
        //} else {
            printf("%s / %s - %d- FAIL\n", str1, str2, s21_strstr(str1, str2));
    
    
    
        }
    
        void s21_strtok_test(char *str1, char *str2) {
        if (str1==s21_strtok(str1, str2)) {
            printf("%s / %s - %d - SUCCESS\n", str1, str2, s21_strtok(str1, str2));
        } else {
            printf("%s / %s - %d- FAIL\n", str1, str2, s21_strtok(str1, str2));
    
        }
    
        */