#include "data_stat.h"

double mean(double *data, int n) {
    double sum = 0;
    for (int i = 0; i < n; i++) {
        sum += data[i];
    }
    return sum / n;
}

double variance(double *data, int n) {
    double result = 0, avg = mean(data, n);
    for (int i = 0; i < n; i++) {
        result += (data[i] - avg) * (data[i] - avg);
    }
    return result / n;
}

double max(double *data, int n) {
    double result = data[0];
    for (int i = 1; i < n; i++) {
        if (data[i] > result) {
            result = data[i];
        }
    }

    return result;
}
double min(double *data, int n) {
    double result = data[0];
    for (int i = 1; i < n; i++) {
        if (data[i] < result) {
            result = data[i];
        }
    }

    return result;
}
