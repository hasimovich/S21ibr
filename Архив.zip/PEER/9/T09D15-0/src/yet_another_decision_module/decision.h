#define GOLDEN_RATIO 0.666
int make_decision(double *data, int n);
