#include "data_io.h"

#include <stdio.h>
#include <stdlib.h>

int input(double *data, int *n) {
    if (scanf("%d", n) == 0 || *n < 0) {
        printf("n/a");

    } else {
        data = realloc(data, *n * sizeof(double));
        for (int i = 0; i < *n; i++) scanf("%lf", &data[i]);
    }

    return 0;
    free(data);
}

void output(double *data, int n) {
    printf("%.2lf ", data[0]);
    for (int i = 1; i < n; i++) printf(" %.2lf", data[i]);
}