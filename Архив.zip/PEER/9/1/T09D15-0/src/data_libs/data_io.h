#ifndef DATA_IO_H_
#define DATA_IO_H_

int input(double *data, int *n);
void output(double *data, int n);

#endif
