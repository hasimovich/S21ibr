#include <math.h>
#ifndef DECISION_H_
#define DECISION_H_
#define GOLDEN_RATIO 0.666

int make_decision(double *data, int n);

#endif
