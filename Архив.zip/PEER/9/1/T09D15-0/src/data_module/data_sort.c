#include <stdio.h>
#include <stdlib.h>

#include "../data_libs/data_stat.h"

void sort(double *data, int n) {
    for (int i = 1; i < n - 1; i++) {
        for (int j = 1; j < n - i - 1; j++) {
            if (data[j] > data[j + 1]) {
                n = data[j];
                data[j] = data[j + 1];
                data[j + 1] = n;
            }
        }
    }
}