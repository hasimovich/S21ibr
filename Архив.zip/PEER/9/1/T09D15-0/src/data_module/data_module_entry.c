#include <stdio.h>
#include <stdlib.h>

#include "../data_libs/data_io.h"
#include "data_process.h"

int main() {
    double *data;
    int n;

    // Don`t forget to allocate memory !
    data = calloc(1, sizeof(double));

    input(data, &n);

    if (normalization(data, n) == 1)
        output(data, n);
    else
        printf("ERROR");

    free(data);
}
