#ifndef DATA_SORT_H_
#define DATA_SORT_H_

void sort(double *data, int n);

#endif
