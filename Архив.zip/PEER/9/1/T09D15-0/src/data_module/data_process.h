#ifndef DATA_PROCESS_H_
#define DATA_PROCESS_H_

#define EPS 1E-6

int normalization(double *data, int n);

#endif
