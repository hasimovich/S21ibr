struct door
{
    int id;
    int status;
};  