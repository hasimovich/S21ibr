#include <stdio.h>
#include <stdlib.h>

int input(int **, int *);
void output(int *, int);
void selectionsort(int *, int);

int main() {
  int n;
  int *data = NULL;

  int is_error = 0;
  is_error = input(&data, &n);
  if (is_error) {
    printf("n/a");
  } else {
    selectionsort(data, n);
    output(data, n);
    free(data);
  }
  return 0;
}

int input(int **a, int *n) {
  int flag = 0;
  if (scanf("%d", n) != 1 && *n <= 0) {
    flag = 1;
  }
  *a = (int *)malloc(*n * sizeof(int));
  for (int *p = *a; p - *a < *n; p++) {
    if (!(scanf("%d", p))) {
      flag = 1;
    }
  }
  return flag;
}

void output(int *a, int n) {
  for (int *p = a; p - a < n; p++) {
    printf("%d", *p);
    if (p - a < n - 1) {
      printf(" ");
    }
  }
}

void selectionsort(int *a, int n) {
  for (int *i = a; i - a < n - 1; i++) {
    /* устанавливаем начальное значение минимального индекса */
    int *min_i = i;
    /* находим индекс минимального элемента */
    for (int *j = i + 1; j - a < n; j++) {
      if (*j < *min_i) {
        min_i = j;
      }
    }
    /* меняем значения местами */
    int temp = *i;
    *i = *min_i;
    *min_i = temp;
  }
}
