#include <stdio.h>
#include <stdlib.h>

int input_type_size(int *, int *, int *);
int input(int **, int, int);

void dynamicAllocation1(int ***, int, int);
void dynamicAllocation2(int ***, int **, int, int);

void output(int **, int, int);

void sort(int **, int, int);
int sum(int *, int);

int main() {
  int N, M, choice;
  int **matrix = NULL;
  int *values_array;

  if (!input_type_size(&choice, &N, &M)) {
    switch (choice) {
    case 1:
      dynamicAllocation1(&matrix, N, M);
      break;
    case 2:
      dynamicAllocation2(&matrix, &values_array, N, M);
      break;
    case 3:
      matrix = (int **)malloc(N * sizeof(int *) + N * M * sizeof(int));
      int *ptr = (int *)(matrix + N);
      for (int i = 0; i < N; i++) {
        matrix[i] = ptr + M * i;
      }
      break;
    }

    if (matrix != NULL) {
      if (!input(matrix, N, M)) {
        sort(matrix, N, M);
        output(matrix, N, M);
        // освобождение памяти
        switch (choice) {
        case 1:
          for (int i = 0; i < N; i++) {
            free(matrix[i]);
          }
          break;
        case 2:
          free(values_array);
          break;
        }
        free(matrix);
      }
    } else {
      printf("n/a");
    }
  } else {
    printf("n/a");
  }

  return 0;
}

int input_type_size(int *type, int *n, int *m) {
  int is_error = 0;
  if (!scanf("%d", type) || *type > 3 || *type < 1) {
    is_error = 1;
  }
  if (!scanf("%d %d", n, m)) {
    is_error = 1;
  }
  return is_error;
}

int input(int **a, int n, int m) {
  int is_error = 0;

  for (int i = 0; i < n; i++) {
    for (int j = 0; j < m; j++) {
      if (!(scanf("%d", &a[i][j])))
        is_error = 1;
    }
  }

  return is_error;
}

void output(int **a, int n, int m) {
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < m; j++) {
      printf("%d", a[i][j]);
      if (j != m - 1) {
        printf(" ");
      }
    }
    if (i != n - 1) {
      printf("\n");
    }
  }
}

void dynamicAllocation1(int ***matrix, int N, int M) {
  *matrix = (int **)malloc(N * sizeof(int *));
  for (int i = 0; i < N; i++) {
    (*matrix)[i] = (int *)malloc(M * sizeof(int));
  }
}

void dynamicAllocation2(int ***matrix, int **values_array, int N, int M) {
  *matrix = (int **)malloc(N * sizeof(int *));
  *values_array = (int *)malloc(M * N * sizeof(int));
  for (int i = 0; i < N; i++) {
    (*matrix)[i] = *values_array + M * i;
  }
}

int sum(int *arr, int n) {
  int sum = 0;
  for (int i = 0; i < n; i++) {
    sum += arr[i];
  }
  return sum;
}

void sort(int **matrix, int n, int m) {
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < m - 1; j++) {
      if (sum(matrix[j], m) > sum(matrix[j + 1], m)) {
        int *tmp = matrix[j];
        matrix[j] = matrix[j + 1];
        matrix[j + 1] = tmp;
      }
    }
  }
}
