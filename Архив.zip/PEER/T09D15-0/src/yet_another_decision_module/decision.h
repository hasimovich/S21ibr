#define GOLDEN_RATIO 0.666
#include "../data_libs/data_stat.h"
#include "../data_libs/data_io.h"
int make_decision(double *data, int n);





            
