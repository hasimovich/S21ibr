#include <stdio.h>
#include <stdlib.h>

#include "decision.h"
int main() {
    int n, flag = 1;
    if (scanf("%d", &n) != 1 || n < 1) {
        flag = 0;
    }

    if (flag) {
        double* data = malloc(n * sizeof(double));

        flag = input(data, n, flag);

        if (flag) {
            if (make_decision(data, n))
                printf("YES");
            else
                printf("NO");
        }

        free(data);
    } else {
        printf("n/a");
    }

    return 0;
}
