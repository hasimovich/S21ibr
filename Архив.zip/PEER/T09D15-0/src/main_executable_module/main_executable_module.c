#include <stdio.h>
#include <stdlib.h>

#include "../data_module/data_process.h"
#include "../yet_another_decision_module/decision.h"

int main() {
    int n, flag = 1;
    if (scanf("%d", &n) != 1 || n < 1) {
        flag = 0;
    }

    if (flag) {
        double* data = malloc(n * sizeof(double));

        printf("LOAD DATA...\n");
        flag = input(data, n, flag);

        if (flag) {
            printf("RAW DATA:\n\t");
            output(data, n);

            printf("\nNORMALIZED DATA:\n\t");
            flag = normalization(data, n, flag);
            if (flag) {
                output(data, n);

                printf("\nSORTED NORMALIZED DATA:\n\t");
                sort(data, n);
                output(data, n);

                printf("\nFINAL DECISION:\n\t");
                if (make_decision(data, n))
                    printf("YES");
                else
                    printf("NO");
            } else {
                printf("ERROR");
            }
        }
    } else {
        printf("n/a");
    }
    return 0;
}
