#include "data_stat.h"

double max(const double *data, int n) {
    double max = *data;
    for (int i = 0; i < n; i++) {
        if (data[i] > max) {
            max = data[i];
        }
    }
    return max;
}

double min(const double *data, int n) {
    double min = *data;
    for (int i = 0; i < n; i++) {
        if (data[i] < min) {
            min = data[i];
        }
    }
    return min;
}

double mean(const double *data, int n) {
    double avg = 0;
    for (int i = 0; i < n; i++) {
        avg += data[i];
    }
    avg /= n;
    return avg;
}

double variance(double *data, int n) {
    double dispersion = 0;
    double avg = mean(data, n);
    for (int i = 0; i < n; i++) {
        dispersion += (data[i] - avg) * (data[i] - avg);
    }
    dispersion /= n;
    return dispersion;
}

void sort(double *data, int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int k = 0; k < n - i - 1; k++) {
            if (*(data + k) > *(data + k + 1)) {
                double tmp = *(data + k);
                *(data + k) = *(data + k + 1);
                *(data + k + 1) = tmp;
            }
        }
    }
}