#include "data_io.h"

#include <stdio.h>
#include <stdlib.h>

int input(double *data, int n, int flag) {
    if (flag) {
        for (int i = 0; i < n; i++) {
            if (flag) {
                if (scanf("%lf", &data[i]) != 1) flag = 0;
            } else {
                printf("n/a");
                break;
            }
        }
    } else {
        printf("n/a");
    }

    return flag;
}

void output(double *data, int n) {
    for (int i = 0; i < n; i++) {
        if (i < n - 1) {
            printf("%.2lf ", data[i]);
        } else {
            printf("%.2lf", data[i]);
        }
    }
}
