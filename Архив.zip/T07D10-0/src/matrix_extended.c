#include <stdio.h>
#include <stdlib.h>

int input(int mem, int *y, int *x);
int metod();
void print(int **parray, int y, int x);
int inpdata(int **parray, int *y, int *x);

// int input(int matst[100][100], int x,int y);

int main() {
    int matst[100][100];
    int mem, x, y;
    //    char c;
    mem = metod();

    if (mem == 0 || (input(mem, &y, &x) == 0))
        printf("n/a");
    else {
        int **parray = NULL;
        int *p2array = NULL;

        switch (mem) {
            case 1:
                if (x > 100 || y > 100) {
                    printf("n/a");
                    break;
                }

                for (int i = 0; i < y; i++) {
                    for (int j = 0; j < x; j++) {
                        scanf("%d", &matst[i][j]);
                    }
                }

                for (int i = 0; i < y; i++) {
                    for (int j = 0; j < x; j++) {
                        if (j == x - 1)
                            printf("%d", matst[i][j]);
                        else
                            printf("%d ", matst[i][j]);
                    }
                    printf("\n");
                }
                /*
                 for (int i = 0; i < y; i++) {
                    for (int j = 0; j < x; j++) {
                      if(j==x-1&&i==y-1) {
                        printf("%d", matst[i][j]);
                        } else if ((j==0)&&(i!=0)) {
                          printf("\n%d ", matst[i][j]);}
                            else {printf("%d ", matst[i][j]);}
                    }
                  }
                */

                break;

            case 2:

                parray = malloc(y * sizeof(int *));
                for (int i = 0; i < y; i++) *(parray + i) = malloc(x * sizeof(int));

                if (inpdata(parray, &y, &x) == 0) {
                    printf("n/a");
                } else
                    print(parray, y, x);

                for (int i = 0; i < y; i++) free(*(parray + i));
                free(parray);
                break;

            case 3:

                parray = malloc(y * sizeof(int *));
                p2array = malloc(y * x * sizeof(int));

                for (int i = 0; i < y; i++) parray[i] = p2array + x * i;

                if (inpdata(parray, &y, &x) == 0) {
                    printf("n/a");
                } else
                    print(parray, y, x);

                free(parray);
                free(p2array);

                break;
            case 4:

                parray = malloc(y * x * sizeof(int) + y * sizeof(int *));
                if (parray == NULL) {
                    printf("n/a");
                    break;
                }
                p2array = (int *)(parray + y);
                for (int i = 0; i < y; i++) parray[i] = p2array + x * i;

                if (inpdata(parray, &y, &x) == 0) {
                    printf("n/a");
                } else
                    print(parray, y, x);

                free(parray);

                break;
            default:
                break;
        }
    }

    return 0;
}

int input(int mem, int *y, int *x) {
    int res = 0;
    char c;

    if (((scanf("%d%c", y, &c) != 2 || *y <= 0) || (mem == 1 && *y > 100)) &&
        ((scanf("%d%c", x, &c) != 2 || *x <= 0) || (mem == 1 && *x > 100))) {
        res = 0;
    } else {
        res = 1;
    }
    return res;
}

int metod() {
    int n;
    char c;
    if (scanf("%d%c", &n, &c) != 2 || (c != '\n') || n <= 0 || n > 4) {
        return 0;
    } else {
        return n;
    }
}

void print(int **parray, int y, int x) {
    int *min = calloc(x, x * sizeof(int));
    int *max = calloc(x, x * sizeof(int));

    for (int j = 0; j < x; j++) *(min + j) = *(*(parray) + j);
    for (int j = 0; j < x; j++) *(max + j) = *(*(parray) + j);

    for (int i = 0; i < y; i++) {
        for (int j = 0; j < x; j++) {
            if (j == x - 1)
                printf("%d", *(*(parray + i) + j));
            else
                printf("%d ", *(*(parray + i) + j));
            if (*(min + j) < *(*(parray + i) + j)) *(min + j) = *(*(parray + i) + j);
            if (*(max + j) > *(*(parray + i) + j)) *(max + j) = *(*(parray + i) + j);
        }
        printf("\n");
    }

    for (int j = 0; j < x; j++)
        if (j == x - 1)
            printf("%d", max[j]);
        else
            printf("%d ", max[j]);
    printf("\n");
    for (int j = 0; j < x; j++)
        if (j == x - 1)
            printf("%d", min[j]);
        else
            printf("%d ", min[j]);
    free(min);
    free(max);
}

int inpdata(int **parray, int *y, int *x) {
    int res = 1;
    for (int i = 0; i < *y; i++) {
        for (int j = 0; j < *x; j++) {
            if (scanf("%d", *(parray + i) + j) != 1) {
                res = 0;
                break;
            }
        }
        if (res == 0) break;
    }

    return res;
}

/*

int input( matst[100][100], int x,int y) {
    char c;
    for (int i = 0; i < y; i++) {
        for (int j = 0; j < x; j++) {
      scanf("%d", &matst[j][i]);
    }
    }

    scanf("%c", &c);
    if (c != '\n') {
      return 0;
    }

return 1;
}
*/