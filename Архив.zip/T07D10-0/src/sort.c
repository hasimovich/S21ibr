#include <stdio.h>
#include <stdlib.h>

int input(int *a, int *n);
void output_result(int *a, int n);
void bubble(int *a, int n);
int inputn();

int main() {
    int n;

    n = inputn();

    int *data = (int *)malloc(n * sizeof(int));
    if (NULL == data) {
        printf("n/a");
        return 0;
    }

    if (input(data, &n) == 0)
        printf("n/a");
    else {
        output_result(data, n);
    }
    free(data);
    return 0;
}

int inputn() {
    int n;
    char c;
    if (scanf("%d%c", &n, &c) != 2 || (c != '\n') || n <= 0) {
        return 0;
    } else {
        return n;
    }
}

int input(int *a, int *n) {
    char c;
    // printf("n=%d",n);

    for (int *p = a; p - a < *n; p++) {
        scanf("%d", p);
    }

    scanf("%c", &c);
    if (c != '\n') {
        // printf("entererr");
        return 0;
    }

    // printf("NEentererr");

    return *n;
}

void bubble(int *a, int n) {
    int c;
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (a[j] > a[j + 1]) {
                c = a[j];
                a[j] = a[j + 1];
                a[j + 1] = c;
            }
        }
    }
}

void output_result(int *a, int n) {
    bubble(a, n);

    for (int *p = a; p - a < n; p++) {
        if (p - a == n - 1)
            printf("%d\n", *p);
        else
            printf("%d ", *p);
    }
}
