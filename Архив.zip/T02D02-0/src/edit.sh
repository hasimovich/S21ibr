cd ..
echo 'Введите путь до файла'
read waytofile
if [[ -f $waytofile ]]
then
echo "Путь корректен"
else
echo "Такого файла нет!"
exit 1
fi
echo 'Путь: '$waytofile'' 
echo "Введите строку для замены"
read chtomen
if [[ $chtomen=="" ]]
then
echo '"ctomen"  меняем на ...'
else
echo "Я не могу заменить пустоту!"
exit 1
fi

echo 'На что меняем?'
read nachtomen
sed -i.bak "s/$chtomen/$nachtomen/" $waytofile
size=$(stat -f "%z" $waytofile)
cdate=$(date -r  $waytofile "+%Y-%m-%d")
hsum=$(shasum -a 256 $waytofile | awk '{print ($1)}')
echo $waytofile - $size - $cdate - $hsum - "sha256" >> files.log