cd ..
read  -p "Введите путь до файла: " waytf
if [[ -f $waytf ]]
then
echo "Путь корректен"
else
echo "Такого файла нет!"
exit 1
fi
sumstr=$(wc -l $waytf | awk '{print ($1)}')
echo Количество записей: $sumstr
sumuf=$(cat $waytf | awk '{print $1}' | sort -u | wc -l)
echo Количество уникальных файлов: $sumuf
sumhsa=$(cat $waytf | awk '{print $1}' | sort -u | wc -l)
let "sumch=$sumhsa-$sumuf"
echo Количество уникальных изменений: $sumch