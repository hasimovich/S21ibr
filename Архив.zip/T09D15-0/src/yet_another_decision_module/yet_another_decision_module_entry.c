#include <stdlib.h>

#include "../data_libs/data_io.h"
#include "../data_libs/data_stat.h"
#include "decision.h"
int main() {
    double *data;
    int n;

    if (scanf("%d", &n) != 1)
        printf("n/a");
    else {
        data = (double *)malloc(n * sizeof(double));
        if (data == NULL)
            printf("n/a");
        else {
            input(data, n);

            if (make_decision(data, n))
                printf("YES");
            else
                printf("NO");
        }
        free(data);
    }
    return 0;
}
