#ifndef SORT_H
#define SORT_H

void sort(double *data, int n);

#endif
