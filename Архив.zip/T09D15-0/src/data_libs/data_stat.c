#include "data_stat.h"

double max(double *data, int n) {
    double x = data[0];
    for (int i = 0; i < n; i++) {
        if (data[i] >= x) x = data[i];
    }
    return x;
}

double min(double *data, int n) {
    double x = data[0];
    for (int i = 0; i < n; i++) {
        if (data[i] <= x) x = data[i];
    }
    return x;
}

double mean(double *data, int n) {
    double means = 0;

    for (double *p = data; p - data < n; p++) means += *p;

    return means / n;
}

double variance(double *data, int n) {
    double variance = 0;
    double meanv = 0;
    for (double *p = data; p - data < n; p++) meanv += *p;

    meanv = meanv / n;

    for (double *p = data; p - data < n; p++) variance += (meanv - *p) * (meanv - *p);

    return variance / n;
}
