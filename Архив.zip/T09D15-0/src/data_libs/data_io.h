#include <stdio.h>
#ifndef DATA_IO_H_
#define DATA_IO_H_

void input(double *data, int n);
void output(double *data, int n);

#endif
