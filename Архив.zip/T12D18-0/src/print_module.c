#include "print_module.h"

#include <stdio.h>
#include <string.h>
#include <time.h>

char print_char(char ch) { return putchar(ch); }

void print_log(char (*print_char)(char), char* message) {
    // char buffer[256];
    time_t curtime;
    struct tm* loctime;
    curtime = time(NULL);
    loctime = localtime(&curtime);
    // fputs (asctime (loctime), stdout);
    // strftime (buffer, 256, "%H:%M:%S ", loctime);

    int h = loctime->tm_hour;
    int m = loctime->tm_min;
    int s = loctime->tm_sec;
    printf("[LOG] ");
    printf("%02d:%02d:%02d ", h, m, s);

    for (int i = 0; i < (int)strlen(message); i++) {
        print_char(*(message + i));
    }
}