#include <stdio.h>

#include "print_module.h"
//#include "documentation_module.h"

int main() {
    // char *t=strftime(t, sizeof(t), "%T", now);
    char (*print)(char) = print_char;

    print_log(print, Module_load_success_message);

    // strftime(t, sizeof(t), "%T", now);

    // printf("%s", t);

    // availability_mask = check_available_documentation_module(validate, Documents_count, Documents);

    // Output availability for each document....

    return 0;
}
